package controllers

import (
	//"encoding/json"
	//"fmt"
	"github.com/astaxie/beego"
	//"github.com/astaxie/beego/cache"
	//_ "github.com/astaxie/beego/cache/redis"
	"github.com/astaxie/beego/orm"
	"lovehome/models"
	"strconv"
	"time"
)

type OrderController struct {
	beego.Controller
}

//将封装好的返回结构 变成json返回给前段
func (this *OrderController) RetData(resp interface{}) {
	this.Data["json"] = resp
	this.ServeJSON()
}

func (this *OrderController) OrderRelease() {
	beego.Info("========== /api/v1.0/orders OrderRelease succ ======")

	resp := make(map[string]interface{})
	resp["errno"] = models.RECODE_OK
	resp["errmsg"] = models.RecodeText(models.RECODE_OK)

	defer this.RetData(resp)

	getHid := this.GetString("house_id")
	getSd := this.GetString("start_date")
	getEd := this.GetString("end_date")
	if getHid == "" || getSd == "" || getEd == "" {
		beego.Info("URL中Get后的参数有空值")
		resp["errno"] = models.RECODE_PARAMERR
		resp["errmsg"] = models.RecodeText(models.RECODE_PARAMERR)
		return
	}

	timeSd, err := time.Parse("2006-01-02", getEd)
	if err != nil {
		beego.Info("sd转为日期时出错")
		resp["errno"] = models.RECODE_SERVERERR
		resp["errmsg"] = models.RecodeText(models.RECODE_SERVERERR)
		return
	}
	timeEd, err := time.Parse("2006-01-02", getEd)
	if err != nil {
		beego.Info("ed转为日期时出错")
		resp["errno"] = models.RECODE_SERVERERR
		resp["errmsg"] = models.RecodeText(models.RECODE_SERVERERR)
		return
	}

	intHid, err := strconv.Atoi(getHid)
	if err != nil {
		beego.Info("aid转为整型时出错")
		resp["errno"] = models.RECODE_SERVERERR
		resp["errmsg"] = models.RecodeText(models.RECODE_SERVERERR)
		return
	}

	if timeSd.After(timeEd) {
		beego.Info("日期有问题")
		resp["errno"] = models.RECODE_PARAMERR
		resp["errmsg"] = models.RecodeText(models.RECODE_PARAMERR)
		return
	}

	//如果Redis中没有，读取数据库
	o := orm.NewOrm()

	var house models.House

	//house.Id = intHid
	//err := o.Read(&house)

	houseTbl := o.QueryTable("user")
	houseTbl.Filter("house__id", intHid).RelatedSel().One(&house)
	if err != nil {
		//返回错误信息给前端
		beego.Info("database err: err ==", err)
		resp["errno"] = models.RECODE_DBERR
		resp["errmsg"] = models.RecodeText(models.RECODE_DBERR)
		return
	}

	if house.User.Id == this.GetSession("user_id") {
		beego.Info("不能订购自己的房子 err!")
		resp["errno"] = models.RECODE_REQERR
		resp["errmsg"] = models.RecodeText(models.RECODE_REQRR)
		return
	}

	var newOrder models.OrderHouse
	orderUser := house.User
	timeDiff := timeEd - timeSd

	newOrder.User = &orderUser
	newOrder.House = &house
	newOrder.Begin_date = timeSd
	newOrder.End_date = timeEd
	newOrder.Days = timeDiff
	//newOrder.House_price =
}
